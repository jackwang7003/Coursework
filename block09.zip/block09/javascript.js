const welcomeInformation = "You are looking through my projects";
alert(welcomeInformation);